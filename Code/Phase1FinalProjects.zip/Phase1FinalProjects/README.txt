README:
This file describes how each project relates to the project goals.

TestApp: Hello World Android (Tablet and Phone)
newprojtest: Hello World Vex

Android Client/Android Server: Android to Android communication

WEB_SERVER: web server application

SimpleServer: C-Server application for receiving text commands over Wi-fi
AndroidSocketCLIENT_TEXT: Text based client for communicating between Android and Vex
AndroidSocketCLIENT_GUI: GUI based client for communicating between Android and Vex