/** Automatically generated file. DO NOT MODIFY */
package edu.coen4720.bigarms.Server;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}